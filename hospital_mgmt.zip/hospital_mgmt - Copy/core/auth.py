from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from .models import User, Patient, Doctor
from datetime import datetime

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        
        if user is not None:
            login(request, user)
            user.last_login = datetime.now()
            user.save()
            messages.success(request, 'Login successful!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'core/auth/login.html')

def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        role = request.POST.get('role')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
            return render(request, 'core/auth/register.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists.')
            return render(request, 'core/auth/register.html')
        
        user = User(
            username=username,
            email=email,
            password=password,  # Note: In production, use proper password hashing
            role=role
        )
        user.save()
        
        # Create corresponding profile based on role
        if role == 'Patient':
            Patient(
                user=user,
                name=request.POST.get('name'),
                age=int(request.POST.get('age')),
                gender=request.POST.get('gender'),
                contact=request.POST.get('contact')
            ).save()
        elif role == 'Doctor':
            Doctor(
                user=user,
                name=request.POST.get('name'),
                specialty=request.POST.get('specialty'),
                contact=request.POST.get('contact')
            ).save()
        
        messages.success(request, 'Registration successful! Please login.')
        return redirect('login')
    
    return render(request, 'core/auth/register.html')

def logout_view(request):
    logout(request)
    messages.success(request, 'Logged out successfully!')
    return redirect('login')

# API Authentication Views
@api_view(['POST'])
@permission_classes([AllowAny])
def api_login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    user = authenticate(username=username, password=password)
    if user is not None:
        login(request, user)
        user.last_login = datetime.now()
        user.save()
        return Response({
            'message': 'Login successful',
            'user': {
                'id': str(user.id),
                'username': user.username,
                'email': user.email,
                'role': user.role
            }
        })
    return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['POST'])
@permission_classes([AllowAny])
def api_register(request):
    username = request.data.get('username')
    email = request.data.get('email')
    password = request.data.get('password')
    role = request.data.get('role')
    
    if User.objects.filter(username=username).exists():
        return Response({'error': 'Username already exists'}, status=status.HTTP_400_BAD_REQUEST)
    
    if User.objects.filter(email=email).exists():
        return Response({'error': 'Email already exists'}, status=status.HTTP_400_BAD_REQUEST)
    
    user = User(
        username=username,
        email=email,
        password=password,  # Note: In production, use proper password hashing
        role=role
    )
    user.save()
    
    # Create corresponding profile based on role
    if role == 'Patient':
        Patient(
            user=user,
            name=request.data.get('name'),
            age=int(request.data.get('age')),
            gender=request.data.get('gender'),
            contact=request.data.get('contact')
        ).save()
    elif role == 'Doctor':
        Doctor(
            user=user,
            name=request.data.get('name'),
            specialty=request.data.get('specialty'),
            contact=request.data.get('contact')
        ).save()
    
    return Response({'message': 'Registration successful'}, status=status.HTTP_201_CREATED)

@api_view(['POST'])
def api_logout(request):
    logout(request)
    return Response({'message': 'Logged out successfully'}) 