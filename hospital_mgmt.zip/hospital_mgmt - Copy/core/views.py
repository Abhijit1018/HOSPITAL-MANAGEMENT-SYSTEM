from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import *
from datetime import datetime

# Function-based views for web interface
@login_required
def index(request):
    context = {
        'total_patients': Patient.objects.count(),
        'total_doctors': Doctor.objects.count(),
        'total_appointments': Appointment.objects.count(),
        'recent_appointments': Appointment.objects.order_by('-appointment_date')[:5]
    }
    return render(request, 'core/index.html', context)

@login_required
def patient_list(request):
    patients = Patient.objects.all()
    return render(request, 'core/patient_list.html', {'patients': patients})

@login_required
def doctor_list(request):
    doctors = Doctor.objects.all()
    return render(request, 'core/doctor_list.html', {'doctors': doctors})

@login_required
def appointment_list(request):
    appointments = Appointment.objects.all()
    return render(request, 'core/appointment_list.html', {'appointments': appointments})

# REST API Views
class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if self.request.user.role == 'Admin':
            return User.objects.all()
        return User.objects.filter(id=self.request.user.id)

class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    permission_classes = [permissions.IsAuthenticated]

class PatientViewSet(viewsets.ModelViewSet):
    queryset = Patient.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if self.request.user.role in ['Admin', 'Doctor']:
            return Patient.objects.all()
        return Patient.objects.filter(user=self.request.user)

class DoctorViewSet(viewsets.ModelViewSet):
    queryset = Doctor.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if self.request.user.role == 'Admin':
            return Doctor.objects.all()
        return Doctor.objects.filter(user=self.request.user)

class AppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'Admin':
            return Appointment.objects.all()
        elif user.role == 'Doctor':
            return Appointment.objects.filter(doctor__user=user)
        return Appointment.objects.filter(patient__user=user)

class MedicalRecordViewSet(viewsets.ModelViewSet):
    queryset = MedicalRecord.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'Admin':
            return MedicalRecord.objects.all()
        elif user.role == 'Doctor':
            return MedicalRecord.objects.filter(doctor__user=user)
        return MedicalRecord.objects.filter(patient__user=user)

class PrescriptionViewSet(viewsets.ModelViewSet):
    queryset = Prescription.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'Admin':
            return Prescription.objects.all()
        elif user.role == 'Doctor':
            return Prescription.objects.filter(doctor__user=user)
        return Prescription.objects.filter(patient__user=user)

class BillViewSet(viewsets.ModelViewSet):
    queryset = Bill.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role in ['Admin', 'Staff']:
            return Bill.objects.all()
        return Bill.objects.filter(patient__user=user)

# API endpoints for specific operations
@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def schedule_appointment(request):
    try:
        patient = Patient.objects.get(user=request.user)
        doctor = Doctor.objects.get(id=request.data.get('doctor_id'))
        department = Department.objects.get(id=request.data.get('department_id'))
        
        appointment = Appointment(
            patient=patient,
            doctor=doctor,
            department=department,
            appointment_date=datetime.strptime(request.data.get('appointment_date'), '%Y-%m-%d'),
            appointment_time=request.data.get('appointment_time'),
            reason=request.data.get('reason', '')
        )
        appointment.save()
        return Response({'message': 'Appointment scheduled successfully'}, status=status.HTTP_201_CREATED)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def doctor_availability(request, doctor_id):
    try:
        doctor = Doctor.objects.get(id=doctor_id)
        return Response({
            'available_days': doctor.available_days,
            'available_time_start': doctor.available_time_start,
            'available_time_end': doctor.available_time_end,
            'is_available': doctor.is_available
        })
    except Doctor.DoesNotExist:
        return Response({'error': 'Doctor not found'}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def update_payment_status(request, bill_id):
    try:
        bill = Bill.objects.get(id=bill_id)
        if request.user.role not in ['Admin', 'Staff']:
            return Response({'error': 'Unauthorized'}, status=status.HTTP_403_FORBIDDEN)
        
        bill.payment_status = request.data.get('payment_status')
        bill.payment_method = request.data.get('payment_method')
        bill.save()
        return Response({'message': 'Payment status updated successfully'})
    except Bill.DoesNotExist:
        return Response({'error': 'Bill not found'}, status=status.HTTP_404_NOT_FOUND)
